package firebaseapps.com.pass.Constants;

/**
 * Created by 1405214 on 08-03-2017.
 */

public class Payment_Params {

                     /*   rxConnect2.setParam("user_mobile",REGISTERED_NUMBER);
                        rxConnect2.setParam("status_pay",state);
                        rxConnect2.setParam("transaction_pay_id",id);
                        rxConnect2.setParam("pay_time",time);
                        rxConnect2.setParam("token_id",TOKEN_PASS); */
    public static String USER_MOBILE_KEY="user_mobile";
    public static String STATUS_PAY="status_pay";
    public static String TRANSACTION_PAY_ID="transaction_pay_id";
    public static String PAY_TIME="pay_time";
    public static String TOKEN_ID="token_id";

}
