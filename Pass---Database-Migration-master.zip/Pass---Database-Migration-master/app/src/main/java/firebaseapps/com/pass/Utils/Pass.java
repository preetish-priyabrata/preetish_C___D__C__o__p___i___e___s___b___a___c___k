package firebaseapps.com.pass.Utils;

import android.app.Application;


/**
 * Created by 1405214 on 25-09-2016.
 * This class is used to enable persistance and
 */

public class Pass extends Application {

}
