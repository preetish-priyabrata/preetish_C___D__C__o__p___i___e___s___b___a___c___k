package firebaseapps.com.pass.Constants;

/**
 * Created by 1405214 on 03-04-2017.
 */

public class OPTION_SELECTED {

    public static String OPTION_VEHICLE="VEHICLE";
    public static String OPTION_PASS_VIEW="VIEWPASS";
    public static String OPTION_APPLICATION_PREVIEW="APPLICATION PREVIEW";
    public static String OPTION_CHANGEABLE_APPLICATION="Application";
    public static String OPTION_CHANGEABLE_VEHICLE="vehicle";
}
