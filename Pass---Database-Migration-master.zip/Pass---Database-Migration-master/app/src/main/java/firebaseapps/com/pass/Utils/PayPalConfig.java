package firebaseapps.com.pass.Utils;

/**
 * Created by 1405214 on 30-09-2016.
 */

public class PayPalConfig {

    public static final String PAYPAL_CLIENT_ID = "AXx_SBiSkZeKN9vE9EBlTcmzEw9OBOWkM8uQA-0__o6avdSX6Q3C5wwafw1MCBxOS0RKt78ICd97TNid";

}
