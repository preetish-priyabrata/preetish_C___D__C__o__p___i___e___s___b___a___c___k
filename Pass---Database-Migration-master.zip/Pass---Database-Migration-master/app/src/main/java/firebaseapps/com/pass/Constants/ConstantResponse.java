package firebaseapps.com.pass.Constants;

/**
 * Created by 1405214 on 27-02-2017.
 */

public class ConstantResponse {


    public static String REGISTRATION_SUCCESS_RESPONSE="Data Is received";

}
