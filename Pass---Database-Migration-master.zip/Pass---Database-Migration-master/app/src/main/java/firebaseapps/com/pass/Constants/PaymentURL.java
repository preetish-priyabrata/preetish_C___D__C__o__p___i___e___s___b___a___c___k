package firebaseapps.com.pass.Constants;

/**
 * Created by 1405214 on 05-04-2017.
 */

public class PaymentURL {

    public static String CLIENT_TOKEN_URL="";
    public static String EXECUTE_TRANSACTION_URL="";
}
