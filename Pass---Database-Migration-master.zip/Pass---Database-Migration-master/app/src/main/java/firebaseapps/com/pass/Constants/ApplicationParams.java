package firebaseapps.com.pass.Constants;

/**
 * Created by 1405214 on 28-02-2017.
 */

public class ApplicationParams {

    /**
     * Application Params
     */

    public static String Name="applicant_name";
    public static String Address="applicant_address";
    public static String RegisteredMobile="mobile_registered";
    public static String Mobile="application_mobile";
    public static String PlaceOfVisit="place_visting";
    public static String IDNumber="applicant_id_no";
    public static String IDSource="applicant_id_source";
    public static String DateOfBirthd="dob";
    public static String PurposeOfVisit="purpose_visting";
    public static String DateOfJourney="date_journey";
    public static String PICTURE="picture";
    public static String PICTURE1="picture1";


}
