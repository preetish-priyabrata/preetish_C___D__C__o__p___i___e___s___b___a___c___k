<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Centre For Advanced Training</title>

        <!-- Styles -->
        <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,700,800" rel="stylesheet" type="text/css"><!-- Google web fonts -->
        <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"><!-- font-awesome -->
        <link href="js/dropdown-menu/dropdown-menu.css" rel="stylesheet" type="text/css"><!-- dropdown-menu -->
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"><!-- Bootstrap -->
        <link href="js/fancybox/jquery.fancybox.css" rel="stylesheet" type="text/css"><!-- Fancybox -->
        <link href="js/audioplayer/audioplayer.css" rel="stylesheet" type="text/css"><!-- Audioplayer -->
        <link href="style.css" rel="stylesheet" type="text/css"><!-- theme styles -->

    </head>

    <body role="document">

        <!-- device test, don't remove. javascript needed! -->
        <span class="visible-xs"></span><span class="visible-sm"></span><span class="visible-md"></span><span class="visible-lg"></span>
        <!-- device test end -->

        <div id="k-head" class="container"><!-- container + head wrapper -->
            <?php include './template-header.php'; ?>
        </div><!-- container + head wrapper end -->

        <div id="k-body"><!-- content wrapper -->

            <div class="container"><!-- container -->

                

                <div class="row no-gutter fullwidth"><!-- row -->

                    <div class="col-lg-12 clearfix"><!-- featured posts slider -->

                        <div id="carousel-featured" class="carousel slide" data-interval="4000" data-ride="carousel"><!-- featured posts slider wrapper; auto-slide -->

                            <ol class="carousel-indicators"><!-- Indicators -->
                                <li data-target="#carousel-featured" data-slide-to="0" class="active"></li>
                                <li data-target="#carousel-featured" data-slide-to="1"></li>
                                <li data-target="#carousel-featured" data-slide-to="2"></li>
                                <li data-target="#carousel-featured" data-slide-to="3"></li>
                                
                            </ol><!-- Indicators end -->

                            <div class="carousel-inner"><!-- Wrapper for slides -->

                                <div class="item active">
                                    <img src="img/slide-11.jpg" alt="Image slide 1" />
                                    
                                </div>

                                <div class="item">
                                    <img src="img/slide-22.jpg" alt="Image slide 2" />
                                    
                                </div>

                                <div class="item">
                                    <img src="img/slide-33.jpg" alt="Image slide 3" />
                                    
                                </div>

                                <div class="item">
                                    <img src="img/slide-44.jpg" alt="Image slide 4" />
                                    
                                </div>

                                

                            </div><!-- Wrapper for slides end -->

                            <!-- Controls -->
                            <a class="left carousel-control" href="#carousel-featured" data-slide="prev"><i class="fa fa-chevron-left"></i></a>
                            <a class="right carousel-control" href="#carousel-featured" data-slide="next"><i class="fa fa-chevron-right"></i></a>
                            <!-- Controls end -->

                        </div><!-- featured posts slider wrapper end -->

                    </div><!-- featured posts slider end -->

                </div><!-- row end -->
                
                

                <div class="row no-gutter"><!-- row -->

                    <div class="col-lg-8 col-md-8"><!-- upcoming events wrapper -->

                        <div class="col-padded"><!-- inner custom column -->

                            <?php
//                            Upcoming Programs
//                            Find All Active Program List
                            include './conf.php';
                            $queryProgram = "SELECT * FROM `tbl_program` WHERE `program_status` = 'Active'";
                            $resProgram = mysqli_query($con, $queryProgram);
                            $rowsProgram = mysqli_num_rows($resProgram);
                            if ($rowsProgram) {
                                $i = 1;
                                ?>
                                <ul class="list-unstyled clear-margins"><!-- widgets -->

                                    <li class="widget-container widget_up_events"><!-- widgets list -->

                                        <h1 class="title-widget">Upcoming Training Programs</h1>
                                        <ul class="list-unstyled">
                                            <?php
                                            while ($rowProgram = mysqli_fetch_array($resProgram)) {
                                                ?>
                                                <li class="up-event-wrap">

                                                    <h1 class="title-median"><a href="#" title="<?php echo $rowProgram['program_name']; ?>"><?php echo $rowProgram['program_name']; ?></a></h1>

                                                    <div class="up-event-meta clearfix">
                                                        <div class="up-event-date"><?php echo date("M d, Y", strtotime($rowProgram['upload_date'])); ?></div>
                                                    </div>

                                                    <p>
                                                        <?php
                                                        $queryModule = "SELECT * FROM `tbl_program_module`,`tbl_program` WHERE tbl_program_module.`program_id` = '$rowProgram[0]' "
                                                                . "AND tbl_program_module.`program_id` = tbl_program.`program_id`";
                                                        $resModule = mysqli_query($con, $queryModule);
                                                        $rowsModule = mysqli_num_rows($resModule);
                                                        if ($rowsModule) {
                                                            while ($rowModule = mysqli_fetch_array($resModule)) {
                                                                echo $rowModule['module_name'] . " , ";
                                                            }
                                                        }
                                                        ?>
                                                        &nbsp;&nbsp;
                                                        <a href="training.php?r=<?php echo encryptIt($rowProgram['program_id']) ?>" class="moretag" title="read more">MORE</a>
                                                    </p>

                                                </li>
                                                <?php
                                            }
                                            ?>
                                        </ul>
                                    </li>
                                </ul>
                                <?php
                            }
                            ?>
                        </div><!-- inner custom column end -->

                    </div><!-- upcoming events wrapper end -->

                    <div class="col-lg-4 col-md-4" id="noticeBoard"><!-- misc wrapper -->
                        <?php
                        include './news-and-events.php';
                        ?>                    
                    </div><!-- misc wrapper end -->

                </div><!-- row end -->

            </div><!-- container end -->

        </div><!-- content wrapper end -->

        <div id="template-footer">
            <?php include './template-footer.php'; ?>
        </div>

        <!-- jQuery -->
        <script src="jQuery/jquery-2.1.1.min.js"></script>
        <script src="jQuery/jquery-migrate-1.2.1.min.js"></script>

        <!-- Bootstrap -->
        <script src="bootstrap/js/bootstrap.min.js"></script>

        <!-- Drop-down -->
        <script src="js/dropdown-menu/dropdown-menu.js"></script>

        <!-- Fancybox -->
        <script src="js/fancybox/jquery.fancybox.pack.js"></script>
        <script src="js/fancybox/jquery.fancybox-media.js"></script><!-- Fancybox media -->

        <!-- Responsive videos -->
        <script src="js/jquery.fitvids.js"></script>

        <!-- Audio player -->
        <script src="js/audioplayer/audioplayer.min.js"></script>

        <!-- Pie charts -->
        <script src="js/jquery.easy-pie-chart.js"></script>

        <!-- Google Maps -->
        <script src="https://maps.googleapis.com/maps/api/js?sensor=true"></script>

        <!-- Theme -->
        <script src="js/theme.js"></script>

    </body>
</html> 