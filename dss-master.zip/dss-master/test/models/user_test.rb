require 'test_helper'

class UserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
  # test "create a user and add role" do
  #   user = User.new
  #   user.email = "testviewuser@gmail.com"
  #   user.password = "123456789"
  #   user.save
  #
  #   user.add_role :viewUser
  # end
end
