require 'test_helper'

class DocumentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
  # test "should not save article without name" do
  #   document = Document.new
  #   document.name = "hello"
  #   assert_not document.save
  # end
end
