class ApplicationMailer < ActionMailer::Base
  default from: 'noreply@gpileportal.co.in'
  layout 'mailer'
end
