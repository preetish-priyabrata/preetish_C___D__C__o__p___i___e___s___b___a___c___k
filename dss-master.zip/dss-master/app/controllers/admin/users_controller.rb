module Admin

  class UsersController < ApplicationController
    before_action :authenticate_user!
    before_action :check_role?
    # load_and_authorize_resource

    def index
      @users = User.all.order(:username) - User.with_role(:admin) - User.with_role(:superAdmin)
      @user = User.new
      @roles = Role.all - Role.where("name = ?", "admin") - Role.where("name = ?", "superAdmin")

      @users_role = UsersRole.new
    end

    # def new
    #   @user = User.new
    # end

    def show
        @user = User.friendly.find(params[:id])
        @roles = Role.all
        @groups = Group.all

        @approved_documents = @user.documents_approved.where("approved = ? and deleted = ?", true, false).order(updated_at: :desc)
    end

    def create
      @user = User.new(user_params)
      role = Role.find(params[:role_id])

      @user.username = @user.username.capitalize

      if @user.save
        @user.add_role role.name
        Log.create! description: "<b>#{current_user.email} </b> created user <b>#{@user.email} </b> at #{@user.created_at.strftime '%d-%m-%Y %H:%M:%S'}", role_id: current_user.roles.ids.first
        Log.create! description: "<b>#{current_user.email} </b> added user <b>#{@user.email} </b> to role <b>#{role.name} </b> at #{@user.created_at.strftime '%d-%m-%Y %H:%M:%S'}", role_id: current_user.roles.ids.first

        # ug = UserGroup.create! user_id: @user.id, group_id: group.id

        # Log.create! description: "<b>#{@user.email} </b> added to project <b>#{group.name} </b> at #{ug.created_at}"

        # => code to send email or notify the user/member
        pwd = params[:user][:password]
        UserNotifierMailer.delay(queue: "create user notification").account_create_notification(@user, pwd)
        # UserNotifierMailer.(@user, pwd).deliver

        # => code to send sms to the created user
        if @user.mobile
          send_sms(@user.mobile, "#{@user.roles.last.name}, User account created on GPIL e-portal, please check your email for further info.")
        end

        # if @user.has_role? :approveUser
        #   redirect_to :back, alert: 'User added , Please assign the approve user to a project !'
        # else
        #   redirect_to :back, notice: 'User successfully added'
        # end
        redirect_back fallback_location: root_path, notice: 'User successfully added'
      end
    end

    def edit
      @user = User.friendly.find(params[:id])
    end

    def update
      @user = User.friendly.find(params[:id])
      # if @user.update(user_params)
      #   Log.create! description: "<b>#{current_user.email} </b> updated user <b>#{@user.email} </b> password </b> at #{@user.updated_at.strftime '%d-%m-%Y %H:%M:%S'}", role_id: current_user.roles.ids.first
      #
      #   pwd = params[:user][:password]
      #   UserNotifierMailer.account_update_notification(@user, pwd).deliver # => send updated mail for account updation
      #
      #   if @user.mobile
      #     send_sms(@user.mobile, "User account is updated on GPIL e-portal, please check your email for further info.")
      #   end
      #   redirect_to admin_users_path, notice: "Password Changed successfully"
      # end
    end

    def reset_password
      @user = User.friendly.find(params[:id])
      require "securerandom"
      pass = SecureRandom.urlsafe_base64(10)
      @user.password = pass
      if @user.save
        Log.create! description: "<b>#{current_user.email} </b> updated user <b>#{@user.email} </b> password </b> at #{@user.updated_at.strftime '%d-%m-%Y %H:%M:%S'}", role_id: current_user.roles.ids.first
        # UserNotifierMailer.account_update_notification(@user, pass).delay.deliver

        # => use delayed job to send mail
        UserNotifierMailer.delay(queue: "Reset Password Mail").account_update_notification(@user, pass) # => send updated mail for account updation
        if @user.mobile
          send_sms(@user.mobile, "#{@user.roles.last.name}, User account is updated on GPIL e-portal, please check your email for further info.")
        end
        redirect_to admin_users_path, notice: "Password reset successfully"
      else
        redirect_to admin_users_path, alert: "Error !!, reset failed"
      end

    end

    def disable_user
      @user = User.friendly.find(params[:id])
      @user.soft_delete
      Log.create! description: "<b>#{current_user.email} </b> disabled user <b>#{@user.email}</b> at#{@user.updated_at.strftime '%d-%m-%Y %H:%M:%S'}", role_id: current_user.roles.ids.first
      redirect_back fallback_location: root_path, notice: "User removed from the system"
    end

    def enable_user
      @user = User.friendly.find(params[:id])
      @user.deleted_at = nil
      if @user.save
        Log.create! description: "<b>#{current_user.email} </b> enabled user <b>#{@user.email}</b> at#{@user.updated_at.strftime '%d-%m-%Y %H:%M:%S'}", role_id: current_user.roles.ids.first
        redirect_back fallback_location: root_path, notice: "User account enabled !"
      else
        rredirect_back fallback_location: root_path, alert: "Error, please try agian"
      end
    end

    def destroy
      @user = User.friendly.find(params[:id])
      Log.create! description: "<b>#{current_user.email} </b> removed user <b>#{@user.email} </b> at #{Time.zone.now.strftime '%d-%m-%Y %H:%M:%S'}", role_id: current_user.roles.ids.first
      @user.destroy
      redirect_back fallback_location: root_path, notice: 'user was successfully removed'
    end


    def add_user_role
      @user = User.find(params[:user_id])
      @user.add_role "#{Role.find(params[:role_id]).name}"
      Log.create!(description: "<b>#{current_user.email}</b> assigned role <b>#{Role.find(params[:role_id]).name} </b> to <b>#{@user.email} </b at #{Time.zone.now.strftime '%d-%m-%Y %H:%M:%S'}>", role_id: current_user.roles.ids.first)
      redirect_back fallback_location: root_path
    end

    private

      def user_params
        params.require(:user).permit(:email, :password, :mobile, :designation, :username)
      end
  end

end
