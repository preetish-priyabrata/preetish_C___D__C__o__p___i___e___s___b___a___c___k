class MessagesController < ApplicationController
  def index
  end
end
