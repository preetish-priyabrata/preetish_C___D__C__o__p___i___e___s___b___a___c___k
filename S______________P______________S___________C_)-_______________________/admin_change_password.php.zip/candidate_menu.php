<li><a href="application_form.php">Fill The Form</a></li>
<li><a href="edit_application.php">Edit Form</a></li>
<li><a href='view_app_status.php'>View Application Status</a></li>
<li><a href="download.php">Download Admit Card</a></li>
<li><a href="enquiry.php">Enquiry</a></li>
<!--<li><a href="notice.php">Notice</a></li>-->
<li><a href="candidate_view_que_ans.php">View Answer Key</a></li>
<li><a href="change_password.php">Change Password</a></li>
<li><a class="btn-theme" style="border-radius:20px; background-color:#00003C; color:#FFF;" href="logout.php">Logout</a></li>
