<li><a href="final_vrf_verify_application.php">View Applications</a></li>
<!-- <li><a href="vrf_view_application.php">View Application</a></li> -->

<li><a href="final_verification_change_password.php">Change Password</a></li>
<li><a class="btn-theme" style="border-radius:20px; background-color:#00003C; color:#FFF;" href="logout.php">Logout</a></li>
