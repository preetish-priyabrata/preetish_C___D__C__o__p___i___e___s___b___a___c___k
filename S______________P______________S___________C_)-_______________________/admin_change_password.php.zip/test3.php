<?php 

?>
<a href="test2.php">help</a>