<li><a href="admin_opreational_manage_center.php" title="Manage Center">Manage Center</a></li>
<li><a href='admin_opreational_manage_exam.php'  title="Manage Exam">Manage Exam</a></li>
<li><a href="admin_opreational_manage_notice.php" title="Manage Notices">Manage Notices</a></li>
<li><a href="admin_opreational_manage_change_password.php">Change Password</a></li>
<li><a class="btn-theme" style="border-radius:20px; background-color:#00003C; color:#FFF;" href="logout.php">Logout</a></li>