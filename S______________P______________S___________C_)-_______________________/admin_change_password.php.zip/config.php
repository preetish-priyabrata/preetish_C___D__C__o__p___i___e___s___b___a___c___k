<?php
$conn = mysqli_connect("localhost","preetishadmin","pan@1111","spsc2");
mysqli_select_db($conn,"spsc2");
?>