<li><a href="manage_user.php">Manage User</a></li>
<!-- <li><a href="manage_centre.php">Manage Centre</a></li>
<li><a href="manage_reservation.php">Manage Reservation</a></li>
<li><a href="manage_exam.php">Manage Exam</a></li>
<li><a href="manage_notice.php">Manage Notice</a></li>
<li><a href="manage_age.php">Manage Age</a></li> -->
<li><a href="admintech_change_password.php">Change Password</a></li>
<li><a class="btn-theme" style="border-radius:20px; background-color:#00003C; color:#FFF;" href="logout.php">Logout</a></li>