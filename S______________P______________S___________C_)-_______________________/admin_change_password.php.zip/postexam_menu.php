<!-- <li ><a href='postexm_collect_attendance.php'>Collect Attendance</a></li>
<li><a href="postexm_update_attendance.php">Update Attendance</a></li>
<li><a href='postexm_update_collect_mark.php'>Collect & Update Mark</a></li> -->
<!-- <li><a href='postexm_result_preparation.php'>Result Preparation</a></li> -->
<!-- <li><a href='postexm_publication.php'>Publication</a></li>
<li><a href='postexm_intimation.php'>Send Intimation</a></li> -->
<li class='has-sub'><a href='#' title="Attendance Sheet Report"><small>Attendance Report</small></a>
  	<ul>
	   <li ><a href='postexam_update_attendance.php' title="Update Attendance"><small>Update Attendance</small></a></li>
	     <li ><a href='postexam_preview_attendance.php' title="View Attendance Sheet"><small>View Attendance Sheet</small></a></li>
    </ul>
</li>
<li class='has-sub'><a href='#' title="Mark Entry"><small>Mark Entry</small></a>
  	<ul>
	   <li ><a href='postexam_mark_attendance.php' title="Update Mark Entry"><small>Update Mark Entry</small></a></li>
	     <li ><a href='postexam_mark_view.php' title="View Attendance Sheet"><small>View Marks</small></a></li>
    </ul>
</li>
<li class='has-sub'><a href='#' title="Result Preparation"><small>Result Preparation</small></a>
  	<ul>
	    <li ><a href='postexam_result_entry.php' title="Entry Of Results"><small>Entry Of Results</small></a></li>
	    <li ><a href='postexam_result_view.php' title="View Results"><small>View Results</small></a></li>
    </ul>
</li>
<li class='has-sub'><a href='#' title="Result Publication"><small>Result Publication</small></a>
  	<ul>
	    <li ><a href='postexam_generate_publish.php' title="Generate Results Publication"><small>Generate Results Publication</small></a></li>
	    <li ><a href='postexam_view_publish.php' title="View Results Publication"><small>View Results Publication</small></a></li>
    </ul>
</li>
 <li class='has-sub'><a href='#' title="Intimation"><small>Intimation</small></a>
  	<ul>
	    <li ><a href='generate_intimation.php' title="Generate Intimation List"><small>Generate Intimation List</small></a></li>
	    <li ><a href='postexam_view_intimation.php' title="View Results Publication"><small>View Intimation Report </small></a></li>
	     <li ><a href='postexam_view_list_candidate_intimation.php' title="List Intimation Send candiadate Report"><small>List Intimation Send candiadate Report </small></a></li>
    </ul>
</li>
<li><a href="post_exam_answer_key.php" title="Upload Answer Key"><small>Upload Answer Key</small></a></li>
<li><a href="postexm_change_password.php" title="Change Password"><small>Change Password</small></a></li>
<li><a class="btn-theme" style="border-radius:20px; background-color:#00003C; color:#FFF;" href="logout.php" title="Logout"><small>Logout</small></a></li>