<li><a href="pe_view_app_status.php" title="View Application Status"><small>View App Status</small></a></li>
<li><a href="pe_generate_rollno.php" title="Generate Roll No"><small>Generate Roll No</small></a></li>
<li><a href="pe_assign_roll_to_center.php" title="Assign Roll to Center"><small>Assign Roll to Center</small></a></li>
<li><a href="pe_view_center_status.php" title="View Center Status"><small>View Center Status</small></a></li>
<li class='has-sub'><a href='#' title="Attendance Sheet"><small>Attendance Sheet</small></a>
  	<ul>
	    <li ><a href='pe_generate_attendance.php' title="Generate Attendance Sheet"><small>Generate Attendance Sheet</small></a></li>
	     <li ><a href='pe_view_attendance.php' title="View Attendance Sheet"><small>View Attendance Sheet</small></a></li>
    </ul>
</li>
<!-- <li ><a href='pe_generate_attendance.php' title="Generate Attendance Sheet"><small>Generate Attendance Sheet</small></a></li> -->
<!-- <li><a href='pe_generate_sitting_arrangement.php' title="Generate Sitting Arrangement">Generate Sitting Arrangement</a></a></li> -->
<!-- <li><a href='pe_generate_admit_card.php' title="Generate Admit Card"><small>Generate Admit Card</small></a></li> -->
<li class='has-sub'><a href='#' title="Admit Card"><small>Admit Card</small></a>
  	<ul>
	    <li ><a href='pe_generate_admit_card.php' title="Generate Admit Card"><small>Generate Admit Card</small></a></li>
	     <li ><a href='pre_preview_admit_card.php' title="Preview Admit Card"><small>Preview Admit Card</small></a></li>
    </ul>
</li>
<li><a href="pe_change_password.php" title="Change Password"><small>Change Password</small></a></li>
<li><a class="btn btn-link btn-xs" style="border-radius:10px; background-color:#00003C; color:#FFF;" href="logout.php" title="Logout"><small>Logout</small></a></li>