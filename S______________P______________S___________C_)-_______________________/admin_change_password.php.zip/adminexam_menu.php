<li><a href="adminexam_view_app_status.php">View Application Status</a></li>
<li class='has-sub'><a href='#'>Attendance Report</a>
                          <ul>
                             <li ><a href='adminexam_center_attendance.php'><span>Center wise</span></a></li>
                             <li><a href='adminexam_concise_attendance.php'><span>Concise</span></a></li>
                            </ul>
</li>
<li><a href="adminexam_sitting_arrangement_report.php">Sitting Arrangement</a></li>
<li><a href='adminexam_result.php'>Result</a></li>
<li><a href="adminexam_query_response.php">Query & Response</a></li>
<li><a href="adminexam_upload_ans_key.php">Upload Answer Key</a></li>
<li><a href="adminexam_change_password.php">Change Password</a></li>
<li><a class="btn-theme" style="border-radius:20px; background-color:#00003C; color:#FFF;" href="logout.php">Logout</a></li>