<li><a href="change_logo.php">Change Your Logo</a></li>
<li><a href='change_organisation_name.php'>Change Organisation Name</a></li>
<li><a href="change_footer.php">Change Footer</a></li>
<li><a href="admin_change_password.php">Change Password</a></li>
<li><a class="btn-theme" style="border-radius:20px; background-color:#00003C; color:#FFF;" href="logout.php">Logout</a></li>